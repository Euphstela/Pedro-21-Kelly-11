notas = []
for i in range(4):
    nota = float(input(f"Digite a {i+1}ª nota: "))
    notas.append(nota)

media = sum(notas) / len(notas)

if media >= 70:
    print(f"Média {media:.2f} - Aluno aprovado")
else:
    print(f"Média {media:.2f} - Aluno reprovado")