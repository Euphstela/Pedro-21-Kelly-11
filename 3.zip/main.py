salario = float(input("Digite o salário atual do colaborador: "))

if salario <= 280.00:
    reajuste = 0.20
elif 280.01 <= salario <= 700.00:
    reajuste = 0.15
elif 700.01 <= salario <= 1500.00:
    reajuste = 0.10
else:
    reajuste = 0.05

novo_salario = salario * (1 + reajuste)
print(f"Salário reajustado: R${novo_salario:.2f}")