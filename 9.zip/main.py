primeiroNome = "Will"
segundoNome = "Lucas"

for i in range(4): # Exemplo de 4 interações
    primeiroNome, segundoNome = segundoNome, primeiroNome
    print(f"Interação {i+1}: primeiroNome = {primeiroNome}, segundoNome = {segundoNome}")