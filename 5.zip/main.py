inicio = int(input("Digite o número inicial da PA: "))
razao = int(input("Digite a razão da PA: "))
limite = int(input("Digite o limite da PA: "))

if limite > inicio:
    termo = inicio
    while termo <= limite:
        print(termo)
        termo += razao
else:
    print("O limite deve ser maior que o valor inicial.")